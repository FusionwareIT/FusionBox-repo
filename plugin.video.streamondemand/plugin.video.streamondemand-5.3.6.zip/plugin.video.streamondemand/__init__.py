# -*- coding: utf-8 -*-
#------------------------------------------------------------
# streamondemand
# http://blog.tvalacarta.info/plugin-xbmc/streamondemand/
#------------------------------------------------------------
