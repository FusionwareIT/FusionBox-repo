# script.speedtest
Kodi speedtest.net addon, uses speedtest-cli
